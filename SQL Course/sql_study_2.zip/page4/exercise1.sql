-- dapatkan nilai rata-rata dari kolom price
SELECT AVG(price)
FROM purchases;