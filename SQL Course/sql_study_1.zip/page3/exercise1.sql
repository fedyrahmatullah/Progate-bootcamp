-- Akses kolom "name" dan "price" dari tabel "purchases" 
SELECT name, price FROM purchases;
