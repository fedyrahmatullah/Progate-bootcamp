-- Hapus data yang ber-id 7 di tabel student
DELETE FROM students
WHERE id = 7;
-- Jangan hapus kueri dibawah
SELECT * FROM students;
