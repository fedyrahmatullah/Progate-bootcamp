-- Tambahkan data ke tabel students
INSERT INTO students(name,course)
VALUES("Kate","Java");

-- Jangan menghapus kueri dibawah
select * from students;
