package main

import "fmt"

func main() {
    name1 := "Ninja Ken"
    name2 := "Guru Domba"
    name3 := "Baby Ben"
    
    // Cetak masing-masing string dengan jeda baris menggunakan \n
    fmt.Printf("Selamat datang, %s\n", name1)
    fmt.Printf("Selamat datang, %s\n", name2)
    fmt.Printf("Selamat datang, %s\n", name3)
}
