package main

import "fmt"

func main() {
    weather := "cerah"
    
    // Cetak "Hari ini, cuacanya ____" menggunakan method `Printf` dari paket `fmt`
    fmt.Printf("Hari ini, cuacanya %s", weather)
}
