package main

// Lakukan import paket `fmt`
import "fmt"

func main() {
    // Tulis kembali code di bawah ini menggunakan paket `fmt` untuk mencetak "Hello, world"
    fmt.Println("Hello, world")
}
