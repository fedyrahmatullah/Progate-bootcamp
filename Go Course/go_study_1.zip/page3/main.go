package main

func main() {
    // Cetak "Hello, world"
    println("Hello, world")
    
    // Baris ini seharusnya merupakan sebuah komentar
    
}
