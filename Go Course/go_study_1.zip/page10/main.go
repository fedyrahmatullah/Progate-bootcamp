package main

func main() {
    // Hapus baris `println` di bawah ini karena `s1` belum terdeklarasikan
   
    
    s1 := "Hi, "
    s2 := "world"
    
    // Ubah nilai yang diberikan pada variable saat pendefinisian
    s1 = "Hello, "

    // Karena variable `s1` bertipe string, hapus baris di bawah

    
    // Cetak nilai-nilai dari variable s1 dan s2
    println(s1, s2)
    
}
