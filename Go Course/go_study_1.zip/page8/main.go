package main

func main() {
	var message string = "Hello, world"

	// Perbarui variable `message` dengan "Hello, Go"
    message = "Hello, Go"
    
	println(message)
}
