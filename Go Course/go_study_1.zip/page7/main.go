package main

func main() {
    // Deklarasikan variable `message` dan tetapkan nilai "Hello, world"
    var message string = "Hello, world"
      
    // Cetak nilai dari dari variable `message`
     println(message)
    
}
