package main

func main() {
    // Deklarasikan variable `message` dan tetapkan "Hello, world" pada-nya
    message := "Hello, world"
    
    // Deklarasikan variable `number` dan tetapkan `100` pada-nya 
    number := 100
    
    // Cetak nilai dari `message` dan `number`
    println(message, number)
    
}
