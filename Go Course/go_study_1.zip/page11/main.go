package main

func main() {
    n := 100
    // Kurangkan 10 dari variable `n` lalu tetapkan hasilnya kembali pada `n`
    n -= 10
    
    println(n)
    
    
    m := 10
    // Tambahkan 1 pada variable `m` lalu tetapkan hasilnya kembali pada `m`
    m++
    
    println(m)
}
